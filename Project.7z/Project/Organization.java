import java.util.*;
import java.io.*;

public class Organization
{
   private String name;
   private Admin admin;
   private RequestDonationList currentDonations;
   private ArrayList <Entity> entityList;
   public ArrayList <Donator> donatorList;
   public ArrayList <Beneficiary> beneficiaryList; 
   
   public void Organization()
   {
      this.name= name;
      this.admin= admin;
      this.currentDonations= currentDonations;
      this.entityList= entityList;
      this.donatorList= donatorList;
      this.beneficiaryList= beneficiaryList;
   }
   public String getname()
   {
      return name; 
   }
   public void setname(String name)
   {
      this.name=name; 
   }
   public Admin getAdmin() 
   {
     return admin;
   }
   public void setAdmin(Admin admin) 
   {
     this.admin = admin;
   }
   public RequestDonationList getcurrentDonations()
   {
      return currentDonations;
   }
   public void setcurrentDonations(RequestDonationList currentDonations)
   {
      this.currentDonations=currentDonations; 
   }
   public void setentityList(ArrayList <Entity> entityList)
   {
       this.entityList = entityList;
   }
   public ArrayList <Entity> getentityList()
   {
      return entityList; 
   }
   public void setdonatorList(ArrayList <Donator> donatorList)
   {
       this.donatorList = donatorList;
   }
   public ArrayList <Donator> getdonatorList()
   {
      return donatorList; 
   }
   public void setbaneficiaryList(ArrayList <Beneficiary> beneficiaryList)
   {
       this.beneficiaryList = beneficiaryList;
   }
   public ArrayList <Beneficiary> getbenefiaciaryList()
   {
      return beneficiaryList; 
   }
   public boolean checkDonatorList(String phone)
   {
      for(Donator donator: donatorList)
      {
         if(donator.getPhone().equals(phone))
         { 
            return true;   
         }
      }
      return false;
   }
   public boolean checkBeneficiaryList(String phone)
   {
      for(Beneficiary beneficiary: beneficiaryList)
      {
         if(beneficiary.getPhone().equals(phone))
         { 
            return true;   
         }
      }
      return false;
   }
   public void addEntity(Entity k) throws ExceptionO
   {
      try
      {
        entityList.add(k);
      }
      catch(Exception e) 
      {
          System.out.println ("This entity already exists!" + e.toString());
      }
   }
   public void listEntities(Entity e)
   {
       System.out.println("These are our entities: ");
       for(Entity entity: entityList)
       {
          System.out.println(entity.getDetails());
       }
   }
   public void removeEntity(Entity a)
   {
       entityList.remove(a);
   }
   public void insertDonator(Donator d) throws ExceptionO
   {
      try
      {
         donatorList.add(d);
      }
      catch(Exception e) 
      {
          System.out.println ("This donator already exists!" + e.toString());
      }
   }
   public void removeDonator(Donator d)
   {
       donatorList.remove(d);
   }
   public void listDonators()
   {
      System.out.println("These are our : ");
       for (Donator donator: donatorList)
      {
         ArrayList <Offers> of = donator.getoffersList();
         for(Offers off: of )
         {
             System.out.println ("" + off);
         }
      }
   }
   public void insertBeneficiary(Beneficiary b) throws ExceptionO
   {
      try
      {
         beneficiaryList.add(b);
      }
      catch(Exception e) 
      {
          System.out.println ("This beneficiar already exists!" + e.toString());
      }
   }
   public void removeBeneficiary(Beneficiary b)
   {
       beneficiaryList.remove(b);
   }
   public void listBeneficiaries() 
   { 
       System.out.println("These are our : ");
       for(Beneficiary beneficiary: beneficiaryList) 
       {
          ArrayList <RequestDonationList> rd = beneficiary.getreceivedList();
          ArrayList <Requests> rs = beneficiary.getrequestsList();
          for(RequestDonationList rdon: rd)
          {
             System.out.println ("" + rdon); 
          }
          for (Requests rq: rs)
          {
             System.out.println("" + rq);  
          }
       }
   }
   public void Register() throws ExceptionO
   {
      Scanner reader = new Scanner(System.in);
      System.out.println ("Insert your user Name: ");
      String name =reader.next();
      System.out.println ("Insert your Phone: ");
      String phone =reader.next();
      
      System.out.println("Select 1.Beneficiary \n2.Donator?");
      String choice = reader.next();
      switch(choice) 
      {
          case "1":
          Beneficiary b = new Beneficiary();
          b.setUserInfo(name, phone);
          insertBeneficiary(b);
          break;
          case "2":
          Donator d = new Donator();
          d.setUserInfo(name, phone);
          insertDonator(d);
          break;
          default:
          System.out.println("Wrong input!");
      }    
      reader.close();
   }
}
