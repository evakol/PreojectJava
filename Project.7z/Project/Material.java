class Material extends Entity
{
    private double Level1, Level2, Level3;
    private int people;
    public Material()
    {
       this.Level1=Level1;
       this.Level2=Level2;
       this.Level3=Level3;
       if(people==1)
       {
          System.out.println("You belong to Level1!");
       }
       else if(people>=2 & people<=4)
       {
          System.out.println("You belong to Level2!");
       }
       else
       {
          System.out.println("You belong to Level3!");
       }
    }
    public String getDetails()
    {
      return "This item is Material: \n" + "Level1: \n" + Level1 + " Level2: \n" + Level2 + " Level3: " + Level3;
    }
}
