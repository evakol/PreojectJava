import java.io.*;
import java.lang.*;
import java.util.*;
class RequestDonation implements Comparator <Entity>
{
    private Entity entity;
    private double quantity;
    
    void setEntity(Entity entity)
    {
        this.entity=entity;
    }
    public Entity getEntity()
    {return entity;}
    void setQuantity(double quantity)
    {
      this.quantity=quantity;
    }
    public double getQuantity()
    {
        return quantity;
    }
    public RequestDonation(Entity entity, double quantity)
    {
      this.entity=entity;
      this.quantity=quantity;
    }
    public int compare(Entity Obj1 , Entity Obj2)
    {
      int entityCompare= Obj1.getEntityInfo().compareTo(Obj2.getEntityInfo());
      return entityCompare;
    }
} 
