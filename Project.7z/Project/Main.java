import java.util.*;
public class Main
{
    public static void main (String args [])
    {
        Organization m = new Organization();
        ArrayList<Entity> milk = m.getentityList();         
        ArrayList<Entity> rice = m.getentityList();
        ArrayList<Entity> sugar = m.getentityList();
        ArrayList<Entity> MedicalSupport = m.getentityList();
        ArrayList<Entity> NurserySupport = m.getentityList();
        ArrayList<Entity> BabySitting = m.getentityList();
        
        Admin a1 = new Admin("Dhmhtrhs Papathanasiou","6955699663", true);
        Beneficiary b1 = new Beneficiary("Giwrgos Loukakhs", "6976455123", 2);
        Beneficiary b2 = new Beneficiary("Elena Nikolopoulou", "6932244770", 4);
        Donator d1 = new Donator("Emilia Dhmopoulou" , "6979045321");
        
        
    }
}
