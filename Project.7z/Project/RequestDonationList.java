import java.util.*;
import java.lang.*;
import java.io.*;
public class RequestDonationList
{
    public ArrayList<RequestDonation> rdEntities;
    
    public ArrayList<RequestDonation> getrdEntities()
    {
       return rdEntities;
    }
    public void setRequestDonation(ArrayList <RequestDonation> rdEntities)
    {
      this.rdEntities = rdEntities;
    }
    public List getRequestDonationList(int id) 
    {return rdEntities; }
    void addRequestDonation(RequestDonation r) throws ExceptionR
    {
        if(rdEntities.contains(r))
        {
          int thesi=rdEntities.indexOf(r);
          rdEntities.set(thesi, r);
        }
        else
        {
           try 
           {
              rdEntities.add(r);
           }
           catch (Exception e)
           {
              throw new ExceptionR (e.toString());
           }
        }
    }
    public void removeRequestDonation(RequestDonation r)
    {
       rdEntities.remove(r);
    }
    void modifyRequestDonation(RequestDonation r, double quantity)
    {
       int a=rdEntities.indexOf(r);
       quantity=r.getQuantity();
       rdEntities.set(a , r);
    }
    public void monitorRequestDonation()
    {
       System.out.println(Arrays.toString(rdEntities.toArray()));       
    }
    public void resetRequestDonation()
    {
      rdEntities.clear();
    }
}
    