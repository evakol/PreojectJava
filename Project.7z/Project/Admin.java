class Admin extends User
{
    private boolean isAdmin=true;
    private String AdminPhone= "6955699663";
    
    public Admin(String name, String phone, boolean isAdmin)
    {
       this.name= new String(name);
       this.phone= new String(phone);
       this.isAdmin= isAdmin;
    }
    public void setisAdmin(boolean isAdmin) {this.isAdmin=isAdmin;}
    public boolean getisAdmin() {return isAdmin;}
    public String getAdminPhone() {return AdminPhone;}
}
