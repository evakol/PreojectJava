public abstract class User
{
    public String name;
    public String phone;
    
    public void setUserInfo(String name,String phone) 
    {
        this.name=name;
        this.phone=phone;
    }
    public String getUserInfo() 
    {
        return "Name: " + name + " Phone: " + phone;
    }
    public String getPhone()
    {
      return phone;
    }
}
