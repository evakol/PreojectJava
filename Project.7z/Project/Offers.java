import java.util.*;
public class Offers extends RequestDonationList
{
   public void commit(ArrayList<RequestDonation> rdEntities)
   {
      rdEntities=super.getrdEntities(); 
      rdEntities.remove(rdEntities);
   }
}
