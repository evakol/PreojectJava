public class ExceptionO extends Exception
{
   public ExceptionO() {}
   public ExceptionO(String msg) {super(msg);}
} 
