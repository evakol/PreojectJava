import java.util.*;
public class Menu extends Organization
{
   private String n;
   public void InsertPhone()
   {
       Scanner reader = new Scanner(System.in);
       System.out.println ("Give your phone number: ");
       String n =reader.next();
       reader.close();
   }
   public void checkingAdmin(Admin a) throws ExceptionO
   {
       if (a.getAdminPhone().equals(n))
       {
          System.out.println("Admin user: " + a.getUserInfo()); 
       }
       else if (super.checkDonatorList(n))
       {
          System.out.println("Donator user: " ); 
       }
       else if(super.checkBeneficiaryList(n))
       {
          System.out.println("Beneficiary user: " ); 
       }
       else
       {
           System.out.println ("Create an account!");
           super.Register();
       }       
   }
    public void MenuDonator(double quantity,Donator d) throws ExceptionO
   {
       
       Scanner reader4 = new Scanner(System.in);
      String answer = "y";
      while (answer=="y")
      {
          System.out.println("Dear Donator,Welcome to our Organization <NEKA>! ");
          System.out.println ("Your personal Data are: " + d.getUserInfo());
          System.out.println ("In which entity you want to donate?\n1.Material" +"("+ quantity+ ")" + "\n2.Service"+"("+ quantity +")");
          Scanner reader = new Scanner(System.in);
          String choice = reader.next();
          switch(choice)
          {
             case "1":
             Material m= new Material();
             listEntities(m);
             m.getEntityInfo();
             System.out.println("Do you want to donate?(y/n)");
             Scanner reader2 = new Scanner(System.in);
             String choice2 = reader2.next();
             switch(choice2)
             {
                case "y":
                System.out.println("Add your donation");
                super.addEntity(m);
                break;
                case "n":
                System.exit(0);
                break;
                default:
                System.out.println("Wrong input!");

             }
             break;
             case "2":
             Service s= new Service();
             listEntities(s);
             s.getEntityInfo();
             Scanner reader3 = new Scanner(System.in);
             String choice3 = reader3.next();
             switch(choice3)
             {
                case "y":
                System.out.println("Add your donation");
                super.addEntity(s);
                break;
                case "n":
                System.exit(0);
                break;
                default:
                System.out.println("Wrong input!");

             }
             break;
             default:
             System.out.println("Wrong input!");
          }
          reader.close();
          System.out.println("Do you want to continue? (y/n)");
          answer = reader4.next();
      }
      System.exit(0);
   }
   public void MenuBeneficiary(Beneficiary b)
   {
       System.out.println("Dear Beneficiary,Welcome to our Organization <NEKA>! ");
       System.out.println ("Your personal Data are: " + b.getUserInfo());
   }
   public void MenuAdmin(double quantity, Admin a)
   {
       System.out.println("Welcome,you are the Admin!");
       System.out.println ("Your personal Data are: " + a.getUserInfo()); 
       System.out.println ("Which entity do you want to see? \n1.Material" +"("+ quantity+ ")" + "\n2.Service"+"("+ quantity +")");
       Scanner reader = new Scanner(System.in);
       String choice = reader.next();
       switch(choice)
       {
          case "1":
          Material m = new Material();
          listEntities(m);
          m.getEntityInfo();
          break;
          case "2":
          Service s = new Service();
          listEntities(s);
          s.getEntityInfo();
          break;
          default:
          System.out.println("Try again!");
       }
       super.listBeneficiaries();
       Scanner reader2 = new Scanner(System.in);
       String choice2 = reader2.next();
       Beneficiary b = new Beneficiary();
       ArrayList<RequestDonationList> rl = b.getreceivedList(); 
       switch(choice2)
       {
          case "1":
          
          for(int i=0; i<beneficiaryList.size(); i++)
          {
              System.out.println(beneficiaryList.get(i));
              System.out.println(Arrays.toString(rl.toArray())); 
          }
          break;
          case "2":
          rl.clear();
          break;
          case "3":
          removeBeneficiary(b);
          break;
          default:
          System.out.println("Try again!");
       }
       
       super.listDonators();
       Scanner reader3 = new Scanner(System.in);
       String choice3 = reader3.next();
       Donator d = new Donator();
       ArrayList<Offers> of = d.getoffersList();
       switch(choice3)
       {
          case "1":
          
          for(int i=0; i<donatorList.size(); i++)
          {
              System.out.println(donatorList.get(i));
              System.out.println(Arrays.toString(of.toArray())); 
          }
          break;
          case "2":
          removeDonator(d);
          break;
          default:
          System.out.println("Try again!");
       }
       System.exit(0);
   }
}
