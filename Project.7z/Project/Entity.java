public abstract class Entity
{
      private String name;
      private String description;
      private int id;
      
      void setEntityInfo(String name, String description, int id)
      {
         this.name=name;
         this.description=description;
         this.id=id;
      }
      public String getEntityInfo()
      {
        return "name: " + name + " description: " + description + " id: " + id;    
      }
      abstract String getDetails();
      public String toString()
      {
        return "Info: \n" + getEntityInfo() + " Details: \n" + getDetails() ;    
      }
}
