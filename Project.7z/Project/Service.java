class Service extends Entity
{
    public String getDetails()
    {
      return "This item is Service: \n";
    }
}
