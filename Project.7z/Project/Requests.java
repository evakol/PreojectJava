public class Requests extends RequestDonationList
{
    @Override
    public void addRequestDonation(RequestDonation r) throws ExceptionR
    {
       try
       {
          rdEntities.contains(r); 
       }
       catch (Exception e)
       {
           throw new ExceptionR (e.toString());
       }
    }
    @Override
    public void modifyRequestDonation(RequestDonation r, double quantity)
    {
    
    }
    public void validRequestDonation() 
    {

    }
    public void commit()
    {
       
    }
}
