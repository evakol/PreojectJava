import java.util.*;
class Donator extends User
{
    private ArrayList<Offers> offersList;
    
    public Donator(String name, String phone)
    {
       this.name= new String(name);
       this.phone= new String(phone);
    }
    public ArrayList<Offers> getoffersList()
    {
       return offersList;
    }
    public void setoffersList(ArrayList<Offers> offersList)
    {
       this.offersList=offersList;
    }
}
