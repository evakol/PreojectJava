import java.util.*;
class Beneficiary extends User
{
    private int noPersons=1;
    public ArrayList<RequestDonationList> receivedList;
    private ArrayList<Requests> requestsList;
    
    public Beneficiary(String name, String phone, int noPersons)
    {
       this.name= new String(name);
       this.phone= new String(phone);
       this.noPersons= noPersons;
    }
    public int getnoPersons()
    {
        return noPersons;
    }
    public void setnoPersons(int noPersons)
    {
      this.noPersons=noPersons;
    }
    public ArrayList <RequestDonationList> getreceivedList()
    {
       return receivedList;
    }
    public void setreceivedList(ArrayList<RequestDonationList> receivedList)
    {
       this.receivedList=receivedList;
    }
    public ArrayList <Requests> getrequestsList()
    {
       return requestsList;
    }
    public void setrequestsList(ArrayList<Requests> requestsList)
    {
       this.requestsList=requestsList;
    }
}
